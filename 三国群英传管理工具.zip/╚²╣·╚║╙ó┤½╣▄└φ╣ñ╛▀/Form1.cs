﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace 三国群英传管理工具
{
    public partial class DropManager : Form
    {
        FileStream m_dropItemfs;
        StreamReader m_dropItemReader;
        FileStream m_playersfs;
        StreamReader m_playersReader;
        FileStream m_playersNamefs;
        StreamReader m_playersNameReader;
        public DropManager()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            m_dropItemfs = new FileStream(path + @"DROPITEM.TXT", FileMode.Open, FileAccess.Read);
            m_dropItemReader = new StreamReader(m_dropItemfs, Encoding.GetEncoding(950));
            m_dropItemReader.BaseStream.Seek(0, SeekOrigin.Begin);

            m_playersfs = new FileStream(path + @"Players.txt", FileMode.Open, FileAccess.Read);
            m_playersReader = new StreamReader(m_playersfs, Encoding.GetEncoding(950));
            m_playersReader.BaseStream.Seek(0, SeekOrigin.Begin);

            m_playersNamefs = new FileStream(path + @"PLAYERS_NAME.TXT", FileMode.Open, FileAccess.Read);
            m_playersNameReader = new StreamReader(m_playersNamefs, Encoding.GetEncoding(950));
            m_playersNameReader.BaseStream.Seek(0, SeekOrigin.Begin);

            Encoding fileEntype = GetFileEncodeType(path + @"PLAYERS_NAME.TXT");

            //MessageBox.Show();

            InitializeComponent();
        }

        private void DropManager_Load(object sender, EventArgs e)
        {
            InitListView();
        }

        string GetPlayerName(string playerNameNUM)
        {
            m_playersNameReader.DiscardBufferedData();
            m_playersNameReader.BaseStream.Seek(0, SeekOrigin.Begin);
            m_playersNameReader.BaseStream.Position = 0;

            string playerNameLine = "";
            do
            {

                if (playerNameLine != null && playerNameLine.Contains("item"))
                {
                    string tmpNum = playerNameLine.Split(new char[] { '=', ',' }, 3)[1].Replace(" ", "");
                    if (tmpNum == playerNameNUM)
                    {
                        string playerName = playerNameLine.Split(new char[] { '=', ',' }, 3)[2];//.Replace(" ", "");

                        return playerName;
                    }
                }
                playerNameLine = m_playersNameReader.ReadLine();
                playerNameLine = playerNameLine.Replace("\t", " ").Replace(" ", "");
            } while (playerNameLine != null);

            return null;
        }

        internal const int LOCALE_SYSTEM_DEFAULT = 0x0800;
        internal const int LCMAP_SIMPLIFIED_CHINESE = 0x02000000;
        internal const int LCMAP_TRADITIONAL_CHINESE = 0x04000000;

        [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int LCMapString(int Locale, int dwMapFlags, string lpSrcStr, int cchSrc, [Out] string lpDestStr, int cchDest);
        //繁体转简体
        public static string ToSimplified(string source)
        {
            String target = new String(' ', source.Length);
            int ret = LCMapString(LOCALE_SYSTEM_DEFAULT, LCMAP_SIMPLIFIED_CHINESE, source, source.Length, target, source.Length);
            return target;
        }
        //简体转繁体
        public static string ToTraditional(string source)
        {
            String target = new String(' ', source.Length);
            int ret = LCMapString(LOCALE_SYSTEM_DEFAULT, LCMAP_TRADITIONAL_CHINESE, source, source.Length, target, source.Length);
            return target;
        }

        private bool InitListView()
        {
            string strLine = "";
            string playerNameNUM = "";
            string dropId = "";
            int i = 0;
            do{
                if (strLine.Contains("[character]"))
                {
                    //read single character
                    do
                    {
                        strLine = m_playersReader.ReadLine();
                        if (strLine.Contains("name"))
                        {
                            playerNameNUM = strLine.Split('=')[1].Replace(" ", "");
                        }
                        if (strLine.Contains("drop"))
                        {
                            dropId = strLine.Split('=')[1].Replace(" ", "");
                        }
                        //get name and drop items
                        if (playerNameNUM != "" && dropId != "")
                        {
                            string playerName = GetPlayerName(playerNameNUM);
                            
                            ListViewItem lvi = new ListViewItem();

                            lvi.ImageIndex = i;
                            lvi.Text = ToSimplified(playerName);
                            lvi.SubItems.Add(dropId);
                            lvi.SubItems.Add(playerNameNUM);

                            this.listView1.Items.Add(lvi);
                            i++;
                            //whether reset m_playersNameReader??
                            break;
                        }
                    } while (!strLine.Contains("[character]"));
                    playerNameNUM = "";
                    dropId = "";
                }
                else 
                {
                    strLine = m_playersReader.ReadLine();
                }
            }while(strLine != null);

            return true;
        }

        public System.Text.Encoding GetFileEncodeType(string filename)
        {
            System.IO.FileStream fs = new System.IO.FileStream(filename, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
            Byte[] buffer = br.ReadBytes(2);
            if (buffer[0] >= 0xEF)
            {
                if (buffer[0] == 0xEF && buffer[1] == 0xBB)
                {
                    return System.Text.Encoding.UTF8;
                }
                else if (buffer[0] == 0xFE && buffer[1] == 0xFF)
                {
                    return System.Text.Encoding.BigEndianUnicode;
                }
                else if (buffer[0] == 0xFF && buffer[1] == 0xFE)
                {
                    return System.Text.Encoding.Unicode;
                }
                else
                {
                    return System.Text.Encoding.Default;
                }
            }
            else
            {
                return System.Text.Encoding.Default;
            }
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            int index = listView1.SelectedItems[0].Index;
            String dropId = listView1.Items[index].SubItems[1].Text;
            String playerNum = listView1.Items[index].SubItems[2].Text;
            FillDropItems(dropId);
            FillDropPlayers(playerNum, dropId);
        }

        private bool FillDropPlayers(string playerNum, string dropId)
        {
            m_playersReader.DiscardBufferedData();
            m_playersReader.BaseStream.Seek(0, SeekOrigin.Begin);
            m_playersReader.BaseStream.Position = 0;

            string strLine = "";
            int i = 0;
            string _dropId = "";
            string _playerNum = "";
            this.listView3.Items.Clear();
            //MessageBox.Show(playerNum);
            do
            {
                if (strLine == "[character]")
                {
                    //read single character
                    do
                    {
                        if (strLine.Contains("name"))
                        {
                            _playerNum = strLine.Split('=')[1].Replace(" ", "");
                        }
                        if (strLine.Contains("drop"))
                        {
                            _dropId = strLine.Split('=')[1].Replace(" ", "");
                        }
                        //get name and drop items
                        if (_playerNum != "" && _dropId != "")
                        {
                            if (_dropId == dropId)
                            {
                                string playerName = GetPlayerName(_playerNum);

                                ListViewItem lvi = new ListViewItem();

                                lvi.ImageIndex = i;
                                lvi.Text = ToSimplified(playerName);

                                this.listView3.Items.Add(lvi);
                                i++;
                                //whether reset m_playersNameReader??
                                break;
                            }
                        }
                        strLine = m_playersReader.ReadLine();
                    } while (strLine != null && strLine != "[character]");
                    _playerNum = "";
                    _dropId = "";
                }
                else {
                    strLine = "";
                    strLine = m_playersReader.ReadLine();
                }
            } while (strLine != null);

            return true;
        }

        //read dropitems and fill
        private bool FillDropItems(string dropId) 
        {
            m_dropItemReader.DiscardBufferedData();
            m_dropItemReader.BaseStream.Seek(0, SeekOrigin.Begin);
            m_dropItemReader.BaseStream.Position = 0;
            string strLine = "";
            do
            {
                if (strLine.Contains("drop") && strLine.Contains("="))
                {
                    string[] arr = strLine.Split(new char[] { '=', ',' }, 3);
                    int length = arr.Length;

                    string _dropId = arr[1].Replace(" ", "");
                    string items = "";
                    if (_dropId == dropId)
                    {
                        this.listView2.Items.Clear();
                        items = arr[2].Replace("\t", " ").Replace(" ", "");
                        //fill items
                        string[] item = items.Split(',');
                        for (int i = 0; i < (item.Length / 2) * 2; i += 2)
                        {
                            ListViewItem lvi = new ListViewItem();

                            lvi.ImageIndex = i / 2;
                            lvi.Text = ToSimplified(item[i]);
                            lvi.SubItems.Add(item[i + 1]);

                            this.listView2.Items.Add(lvi);
                        }
                        break;
                    }
                }
                strLine = "";
                strLine = m_dropItemReader.ReadLine();

            } while (strLine != null);
            
            return true;
        }

        /*
        [DllImport("Kernel32.dll")] 
        [DllImport("kernel32", EntryPoint="WideCharToMultiByte")]
        //Unicode 转换成 BIG5： 
        char* UnicodeToBIG5(const wchar_t* szUnicodeString) 
        {     UINT nCodePage = 950; //BIG5     
            int nLength=WideCharToMultiByte(nCodePage,0,szUnicodeString,-1,NULL,0,NULL,NULL);     
            char* pBuffer=new char[nLength+1];     
            WideCharToMultiByte(nCodePage,0,szUnicodeString,-1,pBuffer,nLength,NULL,NULL);     
            pBuffer[nLength]=0;     
            return pBuffer; 
        } 
    
    //繁体中文BIG5 转换成 简体中文 GB2312 
        char* BIG5ToGB2312(const char* szBIG5String) 
        {     
            LCID lcid = MAKELCID(MAKELANGID(LANG_CHINESE,SUBLANG_CHINESE_SIMPLIFIED),SORT_CHINESE_PRC);     
            wchar_t* szUnicodeBuff = BIG5ToUnicode(szBIG5String);     
            char* szGB2312Buff = UnicodeToGB2312(szUnicodeBuff);     
            int nLength = LCMapString(lcid,LCMAP_SIMPLIFIED_CHINESE, szGB2312Buff,-1,NULL,0);     
            char* pBuffer = new char[nLength + 1];     
            LCMapString(0x0804,LCMAP_SIMPLIFIED_CHINESE,szGB2312Buff,-1,pBuffer,nLength);     
            pBuffer[nLength] = 0;           
            delete[] szUnicodeBuff;     
            delete[] szGB2312Buff;     
            return pBuffer; 
        } 
         * */
    }
}
