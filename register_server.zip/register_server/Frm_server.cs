﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace register_server
{
    public partial class Frm_server : Form
    {
        private string serverIni;

        private static string sql_srvAddr = "192.168.0.100";
        //private static string sql_srvAddr = "120.25.239.84";
        private string sql_srvPort;
        private string sql_srvUser;
        private string sql_srvPwd;
        private string accMrgPort;
        private string sqlAccountName;
        public Frm_server()
        {
            InitializeComponent();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            //数据库未连接，账户管理不允许启动
            /*
            if (btn_sql.Text == "连接数据库")
            {
                MessageBox.Show("请先连接数据库！");
                return;
            }
            */
            bool ret =  false;
            if (btn_register.Text == "启用")
            {
                //*/
                //启用监听端口
                CSocketHelper.ServerPort = int.Parse(accMrgPort);
                CSocketHelper.Listen();

                btn_register.Text = "禁用";
                lbl_regstatus.Text = "服务已开启";
                txt_accMrgPort.ReadOnly = true;
                btn_accPortModify.Enabled = false;
            }
            else {
                //关闭监听
                ret = CSocketHelper.StopListen();
                if (!ret)
                {
                    MessageBox.Show("服务关闭失败");
                }
                else
                {
                    btn_register.Text = "启用";
                    lbl_regstatus.Text = "服务已关闭。";
                    txt_accMrgPort.ReadOnly = false;
                    btn_accPortModify.Enabled = true;
                }
            }
        }

        private void Frm_server_Load(object sender, EventArgs e)
        {
            serverIni = System.AppDomain.CurrentDomain.BaseDirectory + "配置文件.ini";
            LoadIniConf();

            sql_srvAddr = txt_sqlsvr.Text;
            sql_srvUser = txt_sqlAcc.Text;
            sql_srvPwd = txt_sqlPwd.Text;

        }

        #region  //界面控件事件和配置加载
        private void txt_sqlsvr_TextChanged(object sender, EventArgs e)
        {
            sql_srvAddr = txt_sqlsvr.Text;

            CIniCtrl.WriteIniData("Server", "ServerIP", sql_srvAddr, serverIni);
        }

        private void txt_sqlAcc_TextChanged(object sender, EventArgs e)
        {
            sql_srvUser = txt_sqlAcc.Text;

            CIniCtrl.WriteIniData("Server", "SqlAccount", sql_srvUser, serverIni);
        }

        private void txt_sqlPwd_TextChanged(object sender, EventArgs e)
        {
            sql_srvPwd = txt_sqlPwd.Text;

            CIniCtrl.WriteIniData("Server", "SqlPasswd", txt_sqlPwd.Text, serverIni);
        }

        private void LoadIniConf() {   
            sql_srvAddr = CIniCtrl.ReadIniData("Server", "ServerIP", "", serverIni);
            if (sql_srvAddr != "")
            {
                txt_sqlsvr.Text = sql_srvAddr;
            }

            sql_srvPort = CIniCtrl.ReadIniData("Server", "SqlPort", "", serverIni);
            if (sql_srvPort == "")
            {
                CIniCtrl.WriteIniData("Server", "SqlPort", "1433", serverIni);
            }
            else 
            {
                txt_sqlPort.Text = sql_srvPort;
            }

            sql_srvUser = CIniCtrl.ReadIniData("Server", "SqlAccount", "", serverIni);
            if (sql_srvUser != "")
            {
                txt_sqlAcc.Text = sql_srvUser;
            }

            sql_srvPwd = CIniCtrl.ReadIniData("Server", "SqlPasswd", "", serverIni);
            if (sql_srvPwd != "")
            {
                txt_sqlPwd.Text = sql_srvPwd;
            }

            accMrgPort = CIniCtrl.ReadIniData("Server", "ListenPort", "", serverIni);
            if (accMrgPort != "")
            {
                txt_accMrgPort.Text = accMrgPort;
            }

            sqlAccountName = CIniCtrl.ReadIniData("Server", "AccountName", "", serverIni);
            if (sqlAccountName != "")
            {
                txt_sqlAccountName.Text = sqlAccountName;
            }

            //版本管理

            string gameVersionFile = CIniCtrl.ReadIniData("Config", "gameVersionFile", "", serverIni);
            if (gameVersionFile != "")
            {
                if (gameVersionFile.Contains("LoginServer.ini") || gameVersionFile.Contains("loginserver.ini"))
                {
                    txt_gameVerFile.Text = gameVersionFile;

                    //读取版本号到vertxt
                    string CurVer = CIniCtrl.ReadIniData("System", "Version", "", txt_gameVerFile.Text);
                    txt_gameVer.Text = CurVer;
                }
                else
                {
                    txt_gameVerFile.Text = "请选择版本文件！";
                }
            }

            string loginVersion = CIniCtrl.ReadIniData("Config", "loginVersion", "", serverIni);
            if (loginVersion != "")
            {
                txt_loginVer.Text = loginVersion;
            }

            string listenStr = CIniCtrl.ReadIniData("Config", "listenString", "", serverIni);
            if (listenStr != "")
            {
                txt_sessionList.Text = listenStr;
            }
        }

        private void btn_sql_Click(object sender, EventArgs e)
        {
            if (btn_sql.Text == "连接数据库")
            {
                //连接数据库
                //*
                string conn_str = "Data Source = " + sql_srvAddr + "," + sql_srvPort + "; Initial Catalog = " + sqlAccountName + "; User Id = " + sql_srvUser + "; Password = " + sql_srvPwd + ";";
                if (!CSGHelper.SqlConn(conn_str))
                {
                    MessageBox.Show("数据库连接失败！");
                    return;
                }
                else
                {
                    MessageBox.Show("数据库连接成功！");

                    btn_sql.Text = "断开连接";
                    lbl_sqlStatus.Text = "数据库已连接";
                    txt_sqlsvr.ReadOnly = true;
                    txt_sqlPort.ReadOnly = true;
                    txt_sqlAcc.ReadOnly = true;
                    txt_sqlPwd.ReadOnly = true;
                    txt_sqlAccountName.ReadOnly = true;
                }
            }
            else
            {
                //*
                if (!CSGHelper.SqlClose())
                {
                    MessageBox.Show("断开数据库连接失败！");
                    return;
                }
                else
                {
                    btn_sql.Text = "连接数据库";
                    lbl_sqlStatus.Text = "数据库未连接";
                    txt_sqlsvr.ReadOnly = false;
                    txt_sqlPort.ReadOnly = false;
                    txt_sqlAcc.ReadOnly = false;
                    txt_sqlPwd.ReadOnly = false;
                    txt_sqlAccountName.ReadOnly = false;
                }
            }
        }

        private void btn_accPortModify_Click(object sender, EventArgs e)
        {
            //文本监测

            //写入
            CIniCtrl.WriteIniData("Server", "ListenPort", txt_accMrgPort.Text, serverIni);
        
        }

        private void txt_accMrgPort_TextChanged(object sender, EventArgs e)
        {
            //文本监测

            //写入
            CIniCtrl.WriteIniData("Server", "ListenPort", txt_accMrgPort.Text, serverIni);
            accMrgPort = txt_accMrgPort.Text;
        }

        private void txt_sqlPort_TextChanged(object sender, EventArgs e)
        {
            //文本监测

            //写入
            CIniCtrl.WriteIniData("Server", "SqlPort", txt_sqlPort.Text, serverIni);
            sql_srvPort = txt_sqlPort.Text;
        }
        private void txt_sqlAccountName_TextChanged(object sender, EventArgs e)
        {
            //写入
            CIniCtrl.WriteIniData("Server", "AccountName", txt_sqlAccountName.Text, serverIni);
            sqlAccountName = txt_sqlAccountName.Text;
        }

        #endregion

        private void Frm_server_Deactivate(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)  //判断是否最小化
            {
                this.ShowInTaskbar = false;  //不显示在系统任务栏
                notifyIcon1.Visible = true;  //托盘图标可见
            } 
        }

        private void btn_gameVerMdfy_Click(object sender, EventArgs e)
        {
            if (txt_gameVerFile.Text.Contains("LoginServer.ini") || txt_gameVerFile.Text.Contains("loginserver.ini"))
            {
                if (txt_gameVer.Text != "" && txt_gameVer.Text != null)
                {
                    //写版本号到loginServer.ini
                    CIniCtrl.WriteIniData("System", "Version", txt_gameVer.Text, txt_gameVerFile.Text);
                }
            }
            else
            {
                MessageBox.Show("错误的文件，请重新选择！");
                txt_gameVerFile.Text = "请选择版本文件！";
                return;
            }
        }

        private void btn_loginVerMdfy_Click(object sender, EventArgs e)
        {
            if (txt_gameVerFile.Text != "" && txt_gameVerFile.Text != null)
            {
                //写版本号到配置文件.ini
                CIniCtrl.WriteIniData("Config", "loginVersion", txt_loginVer.Text, serverIni);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = true;
            fileDialog.Title = "请选择文件";
            fileDialog.Filter = "所有文件(*.*)|*.*";

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                string file = fileDialog.FileName;
                if (file.Contains("LoginServer.ini") || file.Contains("loginserver.ini"))
                {
                    txt_gameVerFile.Text = file;
                }
                else
                {
                    MessageBox.Show("错误的文件，请重新选择！");
                    txt_gameVerFile.Text = "请选择版本文件！";
                    return;
                }
            }

            //读取版本号到vertxt
            string CurVer = CIniCtrl.ReadIniData("System", "Version", "", txt_gameVerFile.Text);
            txt_gameVer.Text = CurVer;

            //保存次路径到工具配置文件
            CIniCtrl.WriteIniData("Config", "gameVersionFile", txt_gameVerFile.Text, serverIni);
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.ShowInTaskbar = true;  //显示在系统任务栏
                this.WindowState = FormWindowState.Normal;  //还原窗体
                notifyIcon1.Visible = false;  //托盘图标隐藏
            }
        }

        private void txt_gameVer_TextChanged(object sender, EventArgs e)
        {
            if (txt_gameVerFile.Text.Contains("LoginServer.ini") || txt_gameVerFile.Text.Contains("loginserver.ini"))
            {
                if (txt_gameVer.Text != "" && txt_gameVer.Text != null)
                {
                    //写版本号到loginServer.ini
                    CIniCtrl.WriteIniData("System", "Version", txt_gameVer.Text, txt_gameVerFile.Text);
                }
            }
            else
            {
                MessageBox.Show("错误的文件，请重新选择！");
                txt_gameVerFile.Text = "请选择版本文件！";
                return;
            }
        }

        private void txt_loginVer_TextChanged(object sender, EventArgs e)
        {
            if (txt_gameVerFile.Text != "" && txt_gameVerFile.Text != null)
            {
                //写版本号到配置文件.ini
                CIniCtrl.WriteIniData("Config", "loginVersion", txt_loginVer.Text, serverIni);
            }
        }

        public static List<string> listListenString = new List<string>();

        private void btn_listAdd_Click(object sender, EventArgs e)
        {
            //要求先关闭检测
            if(btn_startListen.Text == "停止检测")
            {
                MessageBox.Show("请先关闭检测！！");
                return;
            }

            //添加到列表
            if(txt_newSession.Text != "")
            {
                txt_sessionList.Text = txt_sessionList.Text + txt_newSession.Text + ",";
            }

            if (txt_sessionList.Text != "" && txt_sessionList.Text != null)
            {
                //写版本号到配置文件.ini
                CIniCtrl.WriteIniData("Config", "listenString", txt_sessionList.Text, serverIni);
            }
        }

        private void btn_startListen_Click(object sender, EventArgs e)
        {
            if (btn_sql.Text == "连接数据库")
            {
                MessageBox.Show("请先连接数据库！");
                return;
            }

            if (btn_startListen.Text == "启动检测")
            {
                if (txt_sessionList.Text == "" && txt_sessionList.Text == null)
                {
                    MessageBox.Show("请添加检测列表！");
                    return;
                }
                //分解txt_sessionList.Text到list
                if (listListenString.Count > 0)
                {
                    listListenString.Clear();
                }
                
                string lst = txt_sessionList.Text;

                var list = lst.Split(',');
                for (int i = 0; i < list.Length; i++)
                {
                    listListenString.Add(list[i]);
                }
                btn_startListen.Text = "停止检测";

                tm_strListen.Start();
            }
            else if (btn_startListen.Text == "停止检测")
            {
                //分解txt_sessionList.Text到list
                if (listListenString.Count > 0)
                {
                    listListenString.Clear();
                }

                tm_strListen.Stop();

                btn_startListen.Text = "启动检测";
            }
        }

        private void tm_strListen_Tick(object sender, EventArgs e)
        {
            //构建非法QSL SELECT片段
            string sql_1 = "";
            int count = 0;

            foreach(var item in listListenString)
            {
                count++;
                sql_1 += " msg='" + item + "' ";
                if (count < listListenString.Count)
                {
                    sql_1 += " or ";
                }
            }

            sql_1 = "SELECT name FROM [sanollog].[dbo].[Log_Talk_01] where (" + sql_1 + ") ";
            List<string> nameList = CSGHelper.SearchStrCount(sql_1, DateTime.Now.AddHours(-4), DateTime.Now);
            //List<string> nameList = CSGHelper.SearchStrCount(sql_1, DateTime.Now.AddMonths(-4), DateTime.Now);
            List<AccAttr> playAttr = SGDataCtrl.GetPlayAttr();

            foreach (var name in nameList)
            {
                //根据游戏名字获取账户名
                string acc = SGDataCtrl.GetAccByName(name);

                //冻结账户
                string log = CSGHelper.FreezeAccount(acc,1,"非法登录或者使用贝贝！","GM");
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, acc + ":" + log, new StackTrace(new StackFrame(true)));
            }
        }

        private void txt_sessionList_TextChanged(object sender, EventArgs e)
        {
            //要求先关闭检测
            if (btn_startListen.Text == "停止检测")
            {
                MessageBox.Show("请先关闭检测！！");
                return;
            }

            listListenString.Clear();

            if (txt_sessionList.Text != "" && txt_sessionList.Text != null)
            {
                //写版本号到配置文件.ini
                CIniCtrl.WriteIniData("Config", "listenString", txt_sessionList.Text, serverIni);
            }
        }
    }
}
