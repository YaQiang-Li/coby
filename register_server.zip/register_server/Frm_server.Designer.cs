﻿namespace register_server
{
    partial class Frm_server
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_server));
            this.btn_register = new System.Windows.Forms.Button();
            this.lbl_regstatus = new System.Windows.Forms.Label();
            this.txt_sqlAcc = new System.Windows.Forms.TextBox();
            this.txt_sqlPwd = new System.Windows.Forms.TextBox();
            this.txt_sqlsvr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_sql = new System.Windows.Forms.Button();
            this.txt_sqlPort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_accMrgPort = new System.Windows.Forms.TextBox();
            this.btn_accPortModify = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_sqlStatus = new System.Windows.Forms.Label();
            this.txt_sqlAccountName = new System.Windows.Forms.TextBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_loginVerMdfy = new System.Windows.Forms.Button();
            this.btn_gameVerMdfy = new System.Windows.Forms.Button();
            this.txt_loginVer = new System.Windows.Forms.TextBox();
            this.txt_gameVerFile = new System.Windows.Forms.TextBox();
            this.txt_gameVer = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_startListen = new System.Windows.Forms.Button();
            this.btn_listAdd = new System.Windows.Forms.Button();
            this.txt_newSession = new System.Windows.Forms.TextBox();
            this.txt_sessionList = new System.Windows.Forms.TextBox();
            this.tm_strListen = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(345, 19);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(83, 30);
            this.btn_register.TabIndex = 0;
            this.btn_register.Text = "启用";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // lbl_regstatus
            // 
            this.lbl_regstatus.AutoSize = true;
            this.lbl_regstatus.Location = new System.Drawing.Point(448, 28);
            this.lbl_regstatus.Name = "lbl_regstatus";
            this.lbl_regstatus.Size = new System.Drawing.Size(53, 12);
            this.lbl_regstatus.TabIndex = 1;
            this.lbl_regstatus.Text = "未初始化";
            // 
            // txt_sqlAcc
            // 
            this.txt_sqlAcc.Location = new System.Drawing.Point(76, 61);
            this.txt_sqlAcc.Name = "txt_sqlAcc";
            this.txt_sqlAcc.Size = new System.Drawing.Size(91, 21);
            this.txt_sqlAcc.TabIndex = 2;
            this.txt_sqlAcc.Text = "sa";
            this.txt_sqlAcc.TextChanged += new System.EventHandler(this.txt_sqlAcc_TextChanged);
            // 
            // txt_sqlPwd
            // 
            this.txt_sqlPwd.Location = new System.Drawing.Point(232, 60);
            this.txt_sqlPwd.Name = "txt_sqlPwd";
            this.txt_sqlPwd.PasswordChar = '#';
            this.txt_sqlPwd.Size = new System.Drawing.Size(91, 21);
            this.txt_sqlPwd.TabIndex = 2;
            this.txt_sqlPwd.Text = "123456";
            this.txt_sqlPwd.TextChanged += new System.EventHandler(this.txt_sqlPwd_TextChanged);
            // 
            // txt_sqlsvr
            // 
            this.txt_sqlsvr.Location = new System.Drawing.Point(76, 24);
            this.txt_sqlsvr.Name = "txt_sqlsvr";
            this.txt_sqlsvr.Size = new System.Drawing.Size(91, 21);
            this.txt_sqlsvr.TabIndex = 2;
            this.txt_sqlsvr.Text = "127.0.0.1";
            this.txt_sqlsvr.TextChanged += new System.EventHandler(this.txt_sqlsvr_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "地址：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "帐号：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "密码：";
            // 
            // btn_sql
            // 
            this.btn_sql.Location = new System.Drawing.Point(345, 54);
            this.btn_sql.Name = "btn_sql";
            this.btn_sql.Size = new System.Drawing.Size(83, 30);
            this.btn_sql.TabIndex = 0;
            this.btn_sql.Text = "连接数据库";
            this.btn_sql.UseVisualStyleBackColor = true;
            this.btn_sql.Click += new System.EventHandler(this.btn_sql_Click);
            // 
            // txt_sqlPort
            // 
            this.txt_sqlPort.Location = new System.Drawing.Point(232, 24);
            this.txt_sqlPort.Name = "txt_sqlPort";
            this.txt_sqlPort.Size = new System.Drawing.Size(91, 21);
            this.txt_sqlPort.TabIndex = 2;
            this.txt_sqlPort.Text = "1433";
            this.txt_sqlPort.TextChanged += new System.EventHandler(this.txt_sqlPort_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(185, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "端口：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_accMrgPort);
            this.groupBox1.Controls.Add(this.btn_accPortModify);
            this.groupBox1.Controls.Add(this.btn_register);
            this.groupBox1.Controls.Add(this.lbl_regstatus);
            this.groupBox1.Location = new System.Drawing.Point(18, 119);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(588, 72);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "账户管理";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "监听端口：";
            // 
            // txt_accMrgPort
            // 
            this.txt_accMrgPort.Location = new System.Drawing.Point(76, 25);
            this.txt_accMrgPort.Name = "txt_accMrgPort";
            this.txt_accMrgPort.Size = new System.Drawing.Size(91, 21);
            this.txt_accMrgPort.TabIndex = 2;
            this.txt_accMrgPort.TextChanged += new System.EventHandler(this.txt_accMrgPort_TextChanged);
            // 
            // btn_accPortModify
            // 
            this.btn_accPortModify.Location = new System.Drawing.Point(232, 19);
            this.btn_accPortModify.Name = "btn_accPortModify";
            this.btn_accPortModify.Size = new System.Drawing.Size(83, 30);
            this.btn_accPortModify.TabIndex = 0;
            this.btn_accPortModify.Text = "修改端口";
            this.btn_accPortModify.UseVisualStyleBackColor = true;
            this.btn_accPortModify.Click += new System.EventHandler(this.btn_accPortModify_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lbl_sqlStatus);
            this.groupBox2.Controls.Add(this.txt_sqlPwd);
            this.groupBox2.Controls.Add(this.txt_sqlAccountName);
            this.groupBox2.Controls.Add(this.txt_sqlPort);
            this.groupBox2.Controls.Add(this.txt_sqlsvr);
            this.groupBox2.Controls.Add(this.txt_sqlAcc);
            this.groupBox2.Controls.Add(this.btn_sql);
            this.groupBox2.Location = new System.Drawing.Point(18, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(588, 105);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "数据库";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(349, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 3;
            this.label14.Text = "数据库：";
            // 
            // lbl_sqlStatus
            // 
            this.lbl_sqlStatus.AutoSize = true;
            this.lbl_sqlStatus.Location = new System.Drawing.Point(448, 63);
            this.lbl_sqlStatus.Name = "lbl_sqlStatus";
            this.lbl_sqlStatus.Size = new System.Drawing.Size(53, 12);
            this.lbl_sqlStatus.TabIndex = 1;
            this.lbl_sqlStatus.Text = "未初始化";
            // 
            // txt_sqlAccountName
            // 
            this.txt_sqlAccountName.Location = new System.Drawing.Point(408, 24);
            this.txt_sqlAccountName.Name = "txt_sqlAccountName";
            this.txt_sqlAccountName.Size = new System.Drawing.Size(91, 21);
            this.txt_sqlAccountName.TabIndex = 2;
            this.txt_sqlAccountName.Text = "Account";
            this.txt_sqlAccountName.TextChanged += new System.EventHandler(this.txt_sqlAccountName_TextChanged);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "网关";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.btn_loginVerMdfy);
            this.groupBox3.Controls.Add(this.btn_gameVerMdfy);
            this.groupBox3.Controls.Add(this.txt_loginVer);
            this.groupBox3.Controls.Add(this.txt_gameVerFile);
            this.groupBox3.Controls.Add(this.txt_gameVer);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(18, 200);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(587, 101);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "版本管理";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(533, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "浏览...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_loginVerMdfy
            // 
            this.btn_loginVerMdfy.Location = new System.Drawing.Point(204, 63);
            this.btn_loginVerMdfy.Name = "btn_loginVerMdfy";
            this.btn_loginVerMdfy.Size = new System.Drawing.Size(75, 23);
            this.btn_loginVerMdfy.TabIndex = 2;
            this.btn_loginVerMdfy.Text = "修改";
            this.btn_loginVerMdfy.UseVisualStyleBackColor = true;
            this.btn_loginVerMdfy.Click += new System.EventHandler(this.btn_loginVerMdfy_Click);
            // 
            // btn_gameVerMdfy
            // 
            this.btn_gameVerMdfy.Location = new System.Drawing.Point(204, 25);
            this.btn_gameVerMdfy.Name = "btn_gameVerMdfy";
            this.btn_gameVerMdfy.Size = new System.Drawing.Size(75, 23);
            this.btn_gameVerMdfy.TabIndex = 2;
            this.btn_gameVerMdfy.Text = "修改";
            this.btn_gameVerMdfy.UseVisualStyleBackColor = true;
            this.btn_gameVerMdfy.Click += new System.EventHandler(this.btn_gameVerMdfy_Click);
            // 
            // txt_loginVer
            // 
            this.txt_loginVer.Location = new System.Drawing.Point(92, 65);
            this.txt_loginVer.Name = "txt_loginVer";
            this.txt_loginVer.Size = new System.Drawing.Size(98, 21);
            this.txt_loginVer.TabIndex = 1;
            this.txt_loginVer.TextChanged += new System.EventHandler(this.txt_loginVer_TextChanged);
            // 
            // txt_gameVerFile
            // 
            this.txt_gameVerFile.Location = new System.Drawing.Point(396, 27);
            this.txt_gameVerFile.Name = "txt_gameVerFile";
            this.txt_gameVerFile.Size = new System.Drawing.Size(126, 21);
            this.txt_gameVerFile.TabIndex = 1;
            // 
            // txt_gameVer
            // 
            this.txt_gameVer.Location = new System.Drawing.Point(92, 27);
            this.txt_gameVer.Name = "txt_gameVer";
            this.txt_gameVer.Size = new System.Drawing.Size(98, 21);
            this.txt_gameVer.TabIndex = 1;
            this.txt_gameVer.TextChanged += new System.EventHandler(this.txt_gameVer_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "登录器版本：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(325, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "版本文件：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "游戏版本：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(59, 427);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(179, 12);
            this.label9.TabIndex = 7;
            this.label9.Text = "版权所有2015皇朝霸业工作室 | ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(238, 427);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(197, 12);
            this.label10.TabIndex = 7;
            this.label10.Text = "Copyright 2015 by www.52hcby.com";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(447, 427);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 12);
            this.label11.TabIndex = 7;
            this.label11.Text = "All Rights Reserved";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.btn_startListen);
            this.groupBox4.Controls.Add(this.btn_listAdd);
            this.groupBox4.Controls.Add(this.txt_newSession);
            this.groupBox4.Controls.Add(this.txt_sessionList);
            this.groupBox4.Location = new System.Drawing.Point(18, 307);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(588, 110);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "非法检测";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(286, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 3;
            this.label13.Text = "添加";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(202, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 3;
            this.label12.Text = "列表:";
            // 
            // btn_startListen
            // 
            this.btn_startListen.Location = new System.Drawing.Point(468, 38);
            this.btn_startListen.Name = "btn_startListen";
            this.btn_startListen.Size = new System.Drawing.Size(75, 56);
            this.btn_startListen.TabIndex = 2;
            this.btn_startListen.Text = "启动检测";
            this.btn_startListen.UseVisualStyleBackColor = true;
            this.btn_startListen.Click += new System.EventHandler(this.btn_startListen_Click);
            // 
            // btn_listAdd
            // 
            this.btn_listAdd.Location = new System.Drawing.Point(281, 74);
            this.btn_listAdd.Name = "btn_listAdd";
            this.btn_listAdd.Size = new System.Drawing.Size(75, 23);
            this.btn_listAdd.TabIndex = 2;
            this.btn_listAdd.Text = "<<";
            this.btn_listAdd.UseVisualStyleBackColor = true;
            this.btn_listAdd.Click += new System.EventHandler(this.btn_listAdd_Click);
            // 
            // txt_newSession
            // 
            this.txt_newSession.Location = new System.Drawing.Point(281, 41);
            this.txt_newSession.Name = "txt_newSession";
            this.txt_newSession.Size = new System.Drawing.Size(100, 21);
            this.txt_newSession.TabIndex = 1;
            // 
            // txt_sessionList
            // 
            this.txt_sessionList.Location = new System.Drawing.Point(17, 41);
            this.txt_sessionList.Multiline = true;
            this.txt_sessionList.Name = "txt_sessionList";
            this.txt_sessionList.Size = new System.Drawing.Size(226, 56);
            this.txt_sessionList.TabIndex = 0;
            this.txt_sessionList.TextChanged += new System.EventHandler(this.txt_sessionList_TextChanged);
            // 
            // tm_strListen
            // 
            this.tm_strListen.Interval = 3600000;
            this.tm_strListen.Tick += new System.EventHandler(this.tm_strListen_Tick);
            // 
            // Frm_server
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 451);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_server";
            this.Text = "网关 Ver 1.0.0.2";
            this.Deactivate += new System.EventHandler(this.Frm_server_Deactivate);
            this.Load += new System.EventHandler(this.Frm_server_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Label lbl_regstatus;
        private System.Windows.Forms.TextBox txt_sqlAcc;
        private System.Windows.Forms.TextBox txt_sqlPwd;
        private System.Windows.Forms.TextBox txt_sqlsvr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_sql;
        private System.Windows.Forms.TextBox txt_sqlPort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_accMrgPort;
        private System.Windows.Forms.Button btn_accPortModify;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_sqlStatus;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_loginVerMdfy;
        private System.Windows.Forms.Button btn_gameVerMdfy;
        private System.Windows.Forms.TextBox txt_loginVer;
        private System.Windows.Forms.TextBox txt_gameVer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_gameVerFile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_startListen;
        private System.Windows.Forms.Button btn_listAdd;
        private System.Windows.Forms.TextBox txt_newSession;
        private System.Windows.Forms.TextBox txt_sessionList;
        private System.Windows.Forms.Timer tm_strListen;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_sqlAccountName;
    }
}

