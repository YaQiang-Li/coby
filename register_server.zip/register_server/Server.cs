﻿using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Diagnostics;

namespace register_server
{
    public class CCmdDetail
    {
        public static string CmdDetail(byte[] rbyte)
        {
            string ErrInfo = "";
            Tran_Head rcv_h;
            rcv_h = CDataBuil.GetDataHead(rbyte);
            //MessageBox.Show(rcv_h.cmd + "f");

            switch (rcv_h.cmd)
            {
                case (int)CMD_E.CMD_REGISTER: 
                    {
                        Rg_Info rcv_d;
                        rcv_d = CDataBuil.GetDataObj<Rg_Info>(rbyte, rcv_h);
                        ErrInfo = CmdRegister(rcv_d);
                        break;
                    }
                case (int)CMD_E.CMD_GET_VER:
                    {
                        ErrInfo = CmdGetVersion();
                        break;
                    }
                case (int)CMD_E.CMD_MODY_PWD:
                    {
                        Mdfy_Pwd_Info modyInfo;
                        modyInfo = CDataBuil.GetDataObj<Mdfy_Pwd_Info>(rbyte, rcv_h);
                        ErrInfo = CmdModyPwd(modyInfo);
                        break;
                    }
                default:
                    ErrInfo = "result " + System.Text.Encoding.Unicode.GetString(rbyte);
                    break;
            }

            return ErrInfo;
        }
        public static string CmdRegister(Rg_Info rg_info)
        {
            string ErrInfo = "";
            try { 
                //找出传递过来的用户名和密码
                string name = "";
                string passwd = "";

                name = CSecurity.DecryptDES(rg_info.name,rg_info.key);
                passwd = CSecurity.DecryptDES(rg_info.passwd, rg_info.key);
                if (name == rg_info.name || passwd == rg_info.passwd)
                {
                    ErrInfo = "注册失败，请稍后再试！";
                }
                else {
                    ErrInfo = CSGHelper.CreateAccount(name, passwd);
                    LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, "CreateAccount name:" + name + "\tpasswd:" + passwd, new StackTrace(new StackFrame(true)));
                } 
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
                ErrInfo = "注册失败，请稍后再试！";
            }


            return ErrInfo;
        }

        public static string CmdModyPwd(Mdfy_Pwd_Info modyInfo)
        {
            string ErrInfo = "";
            try
            {
                //找出传递过来的用户名和密码
                string name = "";
                string oldpasswd = "";
                string newpasswd = "";

                name = CSecurity.DecryptDES(modyInfo.name, modyInfo.key);
                oldpasswd = CSecurity.DecryptDES(modyInfo.oldpasswd, modyInfo.key);
                newpasswd = CSecurity.DecryptDES(modyInfo.newpasswd, modyInfo.key);
                if (name == modyInfo.name || oldpasswd == modyInfo.oldpasswd
                    || newpasswd == modyInfo.newpasswd)
                {
                    ErrInfo = "修改失败，请稍后再试！";
                }
                else
                {
                    ErrInfo = CSGHelper.ModifyPwd(name, oldpasswd, newpasswd);
                    LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, "ModifyPwd name:" + name + "\toldpasswd:" + oldpasswd + "\tnewpasswd:" + newpasswd, new StackTrace(new StackFrame(true)));
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
                ErrInfo = "注册失败，请稍后再试！";
            }


            return ErrInfo;
        }

        public static string CmdGetVersion()
        {
            string ErrInfo = "";

            try
            {
                string versionIni = System.AppDomain.CurrentDomain.BaseDirectory + verIni;

                //找出传递过来的用户名和密码
                string ver = "";
                string link = "";
                ver = CIniCtrl.ReadIniData("Version", "ver", "", versionIni);
                link = CIniCtrl.ReadIniData("Version", "link", "", versionIni);

                ErrInfo = ver + "版本" + link;
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ErrInfo, new StackTrace(new StackFrame(true)));
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
                ErrInfo = "error";
            }

            return ErrInfo;
        }
        private static string verIni = "Version.ini";
    }

    public class CSocketHelper
    {
        public static bool ISAddSocekt = true;//现在是否继续接收新的客户端连接

        public static int AddressIndex = 0;//这是当前与服务器端连接的第几个客户端 
        //病历号和客户端IP关联表(key:病历号 value:客户端的IP地址,不包含port)
        public static Dictionary<string, string> dic_Patient_IP = new Dictionary<string, string>();
        //客户端IP和客户端连接顺序关联表(key:病历号 value:客户端的IP地址,不包含port)
        public static Dictionary<string, int> dic_IP_Index = new Dictionary<string, int>();
        //客户端集合 key:客户端IP地址,Value:客户端实体
        public static Dictionary<string, Socket> dic_IP_Socket = new Dictionary<string, Socket>();

        private delegate void AcceptDelegete();
        private delegate void ReadDelegete(Socket s);

        public static int ServerPort = 2000;//服务器端端口
        public static Socket serverSocket;//服务器端      
        //用20个线程分别接受一个设备的数据
        public static int ClientCount_Max = 10;//客户端的最大数量


        public static bool Listen()
        {
            try
            {
                AcceptDelegete listen = AcceptConnection;
                IAsyncResult asy = listen.BeginInvoke(null, null);
                //return AcceptConnection();
                return true;
            }
            catch
            {
                return false;
            }
            
        }

        public static bool StopListen()
        {
            try
            {
                serverSocket.Close();

                return true;
            }
            catch(Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
                return false;
            }

        }

        private static void AcceptConnection()
        {
            try
            {
                serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint localEP = new IPEndPoint(IPAddress.Any, ServerPort);
                //将socket绑定到本地的终结点上
                serverSocket.Bind(localEP);
                //开始监听
                serverSocket.Listen(ClientCount_Max);
                serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), serverSocket);
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
            }
        }

        private static void AcceptCallBack(IAsyncResult iar)
        {
            try
            {
                while (ISAddSocekt)
                {
                    //MessageBox.Show(dic_IP_Index.Count + " ");
                    // 调用EndAccept完成BeginAccept异步调用，返回一个新的Socket处理与客户的通信
                    Socket listener = (Socket)iar.AsyncState;
                    Socket clientSocket = serverSocket.EndAccept(iar);
                    IPEndPoint clientPoint = clientSocket.RemoteEndPoint as IPEndPoint;

                    if (dic_IP_Socket.ContainsKey(clientPoint.Address.ToString()))
                    {
                        //dic_IP_Index.Add(clientPoint.Address.ToString(), AddressIndex);
                        //AddressIndex += 1;
                        //去除旧的客户端实体
                        dic_IP_Socket.Remove(clientPoint.Address.ToString());
                        if (dic_IP_Socket.Count < ClientCount_Max)
                        {
                            serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), listener);
                            break;
                        }
                        else
                        {
                            LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, dic_IP_Index.Count + " ", new StackTrace(new StackFrame(true)));
                            serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), listener);
                            break;
                        }
                    }
                    dic_IP_Socket.Add(clientPoint.Address.ToString(), clientSocket);
                    LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, " dic_IP_Index.Count:" + dic_IP_Socket.Count, new StackTrace(new StackFrame(true)));

                    //开启新线程读取数据
                    CM_Data client = new CM_Data(clientSocket);
                    Thread thClient = new Thread(new ThreadStart(client.ClientServer));
                    thClient.Start();
                    //在达到多大的客户端连接限制前，继续监听是否有新的客户端连接
                    if (dic_IP_Socket.Count < ClientCount_Max)
                    {
                        serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), listener);
                        break;
                    }
                    else
                    {
                        LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, dic_IP_Index.Count + " ", new StackTrace(new StackFrame(true)));
                        serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), listener);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
            }
        }
    }


    //在新线程中不同的循环接收客户端发送过来的数据信息
    //  CM_Data类里的代码
    public class CM_Data
    {
        Encoding encoding = Encoding.Unicode; //解码器（可以用于汉字）
        private Socket client;//当前与服务器端通信的客户端实体

        private byte[] receiveBytes = new byte[1024];//服务器端设置缓冲区
        private int recCount;
        byte[] byte_Data;
        //传递连接socket
        public CM_Data(Socket ClientSocket)
        {
            this.client = ClientSocket;
        }

        public void ClientClose(Socket _client)
        {
            try
            {
                LingerOption lingerOption = new LingerOption(true, 0);
                if (_client != null)
                {
                    //MessageBox.Show("_client != null");
                    //MessageBox.Show("_client != null" + CSocketHelper.dic_IP_Socket.Count);
                    //清除记录
                    IPEndPoint clientPoint = _client.RemoteEndPoint as IPEndPoint;
                    CSocketHelper.dic_IP_Socket.Remove(clientPoint.Address.ToString());
                    //MessageBox.Show("_client != null" + clientPoint.Address.ToString() + CSocketHelper.dic_IP_Socket.Count);

                    _client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, lingerOption);
                    //_client.Shutdown(SocketShutdown.Both);
                    _client.Close();
                    _client = null;
                }
                else
                {
                    //MessageBox.Show("else");
                }
            }
            catch(Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
            }
            
        }
                        
        public void ClientServer()
        {
            while (true)
            {
                try
                {
                    client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, 10000);
                    recCount = client.Receive(receiveBytes, receiveBytes.Length, 0);//从客户端接收信息,recCount为有效数据的个数
                    if (recCount != 0)//当服务器端的缓冲区接收到的信息不为空时
                    {
                        byte_Data = new byte[recCount];
                        for (int i = 0; i < recCount; i++)
                        {
                            byte_Data[i] = receiveBytes[i];
                        }
                        //获取数据后的数据处理
                        string result = CCmdDetail.CmdDetail(byte_Data);
                        byte[] ret_data = encoding.GetBytes(result);

                        //client.Shutdown(SocketShutdown.Both);
                        //ClientClose(client);
                        client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, 5000);
                        client.Send(ret_data, 0, ret_data.Length, SocketFlags.None);
                        Thread.Sleep(1000);

                        break;
                    }
                    else
                    {
                        LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, recCount + "", new StackTrace(new StackFrame(true)));
                        break;
                    }
                }
                catch (SocketException se)
                {
                    if (client.Available != 0)
                    {
                    
                    }
                    if (se.ErrorCode == 10060)
                    {
                        IPEndPoint clientPoint = client.RemoteEndPoint as IPEndPoint;
                        LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, clientPoint.Address.ToString()+"非法连接！强制中断", new StackTrace(new StackFrame(true)));
                    }
                    break;
                }
                catch (Exception ex)
                {
                    LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
                    break;
                }
            }

            ClientClose(client);
        }

        private void SendCallBack(IAsyncResult iar)
        {
            try
            {
                Socket workerSocket = (Socket)iar.AsyncState;
                if (workerSocket != null)
                {
                    workerSocket.EndSend(iar);
                    ClientClose(workerSocket);
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog(System.AppDomain.CurrentDomain.BaseDirectory, ex.Message, new StackTrace(new StackFrame(true)));
            }
        }
    }


}
